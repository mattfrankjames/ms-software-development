1. I spent about two hours on this
1. The easiest thing for me with this assignment was thinking through how to break up the functions and what their signatures should be.
1. I had the most difficulty on the dice roller program because I neglected to print out the info on the dice rolls and the sum that corresponded with meeting the intended target sum. Consequently, I kept seeing the second to last roll and sum, so I thought something was broken. Once I figured out that I needed that outside of the validation loop, everything was fine.
