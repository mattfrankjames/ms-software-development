1. I probably spent around eight hours total on this between planning and execution
1. The easiest part was using top down design to put this together.
1. The hardest part was that I've been interviewing for jobs a few times a week, which often involve live code challenges. So, context switching between JavaScript and Python and preparing for those interviews while working on this was quite challenging.
1. I don't know if there's anything I deserve extra credit for but I'm happy with the way you can't collect the same item or encounter the same enemy more than once. I'm also happy with the variety of options that end the game and the number of enemy/spell combinations.
