1. I spent around two and a half hours on these assignments.
1. The easiest aspect of this was formatting the string in the unique list assignment.
1. The hardest part was structuring the loops properly for the machine status assignment so that they would increment the values at the appropriate intervals.